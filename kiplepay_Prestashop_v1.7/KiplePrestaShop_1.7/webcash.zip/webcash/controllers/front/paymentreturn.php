<?php
/**
 *
 * @author    DerikonDevelopment <ionut@derikon.com>
 * @copyright Copyright (c) permanent, DerikonDevelopment
 * @license   Addons PrestaShop license limitation
 * @version   1.0.4
 * @link      http://www.derikon.com/
 *
 */


class WebcashPaymentReturnModuleFrontController extends ModuleFrontController {
	public function __construct() {
		parent::__construct();
		$this->display_column_right = false;
		$this->display_column_left  = false;
		$this->context              = Context::getContext();
	}

	public function init() {
		parent::init();
		$cart = $this->context->cart;
		if ( $cart->id_customer == 0 || $cart->id_address_delivery == 0 || $cart->id_address_invoice == 0 || ! $this->module->active ) {
			Tools::redirect( 'index.php?controller=order&step=1' );
		}

		$authorized = false;
		foreach ( Module::getPaymentModules() as $module ) {

			if ( $module['name'] == 'webcash' ) {
				$authorized = true;
				break;
			}
		}

		if ( ! $authorized ) {
			die( $this->module->l( 'Webcash payment method is not available.', 'paymentreturn' ) );
		}

		$customer = new Customer( $cart->id_customer );
		if ( ! Validate::isLoadedObject( $customer ) ) {
			Tools::redirect( 'index.php?controller=order&step=1' );
		}
		$cart_total = $cart->getOrderTotal( true, Cart::BOTH );
		
		$amount_cart = number_format($cart_total, 2, '.', '');
		if (round($amount_cart)== $_REQUEST['ord_totalamt']) { $amt_cart = $amount_cart; }

		$webcash = new webcash();
		$webcash_name = 'Kiple Online Payment Gateway';

		$merchantCode = Configuration::get('webcash_merchantCode');
		$merchantKey = Configuration::get('webcash_merchantKey');

		$retcode=$_REQUEST['returncode'];
		$amount = $_REQUEST['ord_totalamt'];
		$merchantID = $_REQUEST['ord_mercID'];
		$referenceNo = $_REQUEST['ord_mercref'];

		$amountVal = str_replace(".","",str_replace(",","",$amount));
		$hashvalue = sha1($merchantKey.$merchantCode.$referenceNo.$amountVal.$retcode);

		if ($retcode == "100" && $_REQUEST['ord_key'] == $hashvalue) {  // successful transaction

			$result = $this->Requery($referenceNo, $merchantID, $amount);

		    if ($result) {
		    	
		      $webcash->validateOrder(intval($cart->id), _PS_OS_PAYMENT_, $amount_cart, $webcash->displayName);
		      Tools::redirectLink(__PS_BASE_URI__.'order-confirmation.php?id_cart='.$cart->id.'&id_module='.$webcash->id);    
		    } else {
		    	
		      $webcash->validateOrder(intval($cart->id), _PS_OS_ERROR_, $amount_cart, $webcash->displayName);
		      Tools::redirectLink(__PS_BASE_URI__.'index.php?controller=history');
		    }
		  
		} else if ($retcode == "E2" || $retcode == "E1") { // failure transaction
		  	$webcash->validateOrder(intval($cart->id), _PS_OS_ERROR_, $amount_cart, $webcash->displayName);
		  	Tools::redirectLink(__PS_BASE_URI__.'index.php?controller=history');

		}
	}
	
	public	function Requery($ref, $mercId, $amount){
	  $url = "https://uat.kiplepay.com/enquiry.php";        // Production -> https://kiplepay.com/enquiry.php
	  $query = $url."?ord_mercref=" . $ref . "&ord_mercID=" . $mercId . "&ord_totalamt=" . $amount; 

	  $response = file_get_contents($query);
	  if ($response == 'S') {
	    return true;
	  }
	  return false;
	}

}
