Copy:

1) order-failed.tpl  -> to all themes directory
2) order-failed.php  -> to shop home directory

Copy Webcash folder to /modules

Configure at admin !